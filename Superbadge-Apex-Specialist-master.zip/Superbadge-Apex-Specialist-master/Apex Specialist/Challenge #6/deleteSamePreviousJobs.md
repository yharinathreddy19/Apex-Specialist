# Intructions to pass this challenge
* from Setup place 'Scheduled Jobs' in quick find box
* select the option 'Scheduled Jobs'
* delete the previous job for WarehouseSyncScheduleTest class (i.e delete the record for Job Name = WarehouseSyncScheduleTest)
* now run the test class WarehouseSyncScheduleTest
* now check to pass the challenge (click 'Check Challenge)
